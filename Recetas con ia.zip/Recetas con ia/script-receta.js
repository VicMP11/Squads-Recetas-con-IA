document.addEventListener('DOMContentLoaded', () => {
    // 1. LEER DEL STORAGE
    const datosReceta = localStorage.getItem('recetaGenerada');

    if (!datosReceta) {
        // Si alguien entra directamente a esta página sin generar receta, lo devolvemos
        window.location.href = 'index.html';
        return;
    }

    let receta;
    try {
        receta = JSON.parse(datosReceta);
    } catch (e) {
        console.error("Error al leer la receta:", e);
        return;
    }

    // 2. RECONSTRUIR EL HTML
    // Título y Dificultad
    const titleElem = document.getElementById('recipeTitle');
    const diffElem = document.getElementById('recipeDifficulty');

    if (titleElem) titleElem.innerText = receta.titulo;
    if (diffElem) diffElem.innerText = receta.dificultad;

    // Lista de Ingredientes
    const listaIngredientes = document.getElementById('ingredientsList');
    if (listaIngredientes && receta.ingredientes) {
        listaIngredientes.innerHTML = receta.ingredientes.map(ing => `
            <label class="item"><input type="checkbox"> ${ing}</label>
        `).join('');
    }

    // Pasos de Preparación
    const contenedorPasos = document.getElementById('stepsContainer');
    if (contenedorPasos && receta.pasos) {
        contenedorPasos.innerHTML = receta.pasos.map((paso, index) => `
            <div class="step">
                <div class="step-number">${index + 1}</div>
                <div>
                    <h3>${paso.paso_titulo}</h3>
                    <p>${paso.descripcion}</p>
                </div>
            </div>
        `).join('');
    }
});