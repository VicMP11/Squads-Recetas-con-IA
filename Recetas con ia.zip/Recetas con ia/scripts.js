import { obtenerRecetaIA } from './api-gemini.js';
const dbIngredientes = [
    { "nombre": "Tomate", "imagen_url": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=500&auto=format&fit=crop" },
    { "nombre": "Aguacate", "imagen_url": "https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?q=80&w=500&auto=format&fit=crop" },
    { "nombre": "Huevo", "imagen_url": "https://i.blogs.es/09c069/huevo/450_1000.webp" },
    { "nombre": "Harina de Trigo", "imagen_url": "https://images.unsplash.com/photo-1509440159596-0249088772ff?q=80&w=500&auto=format&fit=crop" },
    { "nombre": "Aceite de Oliva", "imagen_url": "https://i.blogs.es/6df34a/olive-oil-968657_1280-2-/1366_2000.jpg" },
    { "nombre": "Ajo", "imagen_url": "https://images.unsplash.com/photo-1540148426945-6cf22a6b2383?q=80&w=500&auto=format&fit=crop" },
    { "nombre": "Cebolla", "imagen_url": "https://images.unsplash.com/photo-1508747703725-719777637510?q=80&w=500&auto=format&fit=crop" },
    { "nombre": "Pechuga de Pollo", "imagen_url": "https://images.unsplash.com/photo-1604503468506-a8da13d82791?q=80&w=500&auto=format&fit=crop" },
    { "nombre": "Leche", "imagen_url": "https://www.recetasnestlecam.com/sites/default/files/2024-04/jarra-vaso-tipo-leche_0.jpg" },
    { "nombre": "Arroz Blanco", "imagen_url": "https://images.unsplash.com/photo-1586201375761-83865001e31c?q=80&w=500&auto=format&fit=crop" },
    { "nombre": "Zanahoria", "imagen_url": "https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?q=80&w=500&auto=format&fit=crop" },
    { "nombre": "Brócoli", "imagen_url": "https://images.unsplash.com/photo-1452948491233-ad8a1ed01085?q=80&w=500&auto=format&fit=crop" },
    { "nombre": "Limón", "imagen_url": "https://images.unsplash.com/photo-1590502593747-42a996133562?q=80&w=500&auto=format&fit=crop" },
    { "nombre": "Mantequilla", "imagen_url": "https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?q=80&w=500&auto=format&fit=crop" },
    { "nombre": "Pasta", "imagen_url": "https://assets.tmecosys.com/image/upload/t_web_rdp_recipe_584x480_1_5x/img/recipe/ras/Assets/658A0A74-039A-487C-A07A-CAAF61B4615D/Derivates/A230DF28-60DF-429D-ABDA-96ED64E9EE10.jpg" },
    { "nombre": "Salmón", "imagen_url": "https://images.unsplash.com/photo-1467003909585-2f8a72700288?q=80&w=500&auto=format&fit=crop" },
    { "nombre": "Pimiento Rojo", "imagen_url": "https://ecosdelatierra.es/wp-content/uploads/2021/08/Pimiento-Rojo-Ecologico-California.jpg" },
    { "nombre": "Queso Parmesano", "imagen_url": "https://images.unsplash.com/photo-1452195100486-9cc805987862?q=80&w=500&auto=format&fit=crop" },
    { "nombre": "Patata", "imagen_url": "https://images.unsplash.com/photo-1518977676601-b53f82aba655?q=80&w=500&auto=format&fit=crop" },
    { "nombre": "Manzana Rojo", "imagen_url": "https://www.gustavoferrada.es/wp-content/uploads/2019/10/manzana-roja-1.jpg" }
];

window.onload = () => {
    const input = document.getElementById('ingredientInput');
    const ingredientsGrid = document.getElementById('ingredientsGrid');
    const findRecipesBtn = document.getElementById('findRecipesBtn');
    let selectedIngredients = [];

    function renderIngredients(lista) {
        if (!ingredientsGrid) return; // Seguridad
        ingredientsGrid.innerHTML = '';
        lista.forEach((ingredient) => {
            const isSelected = selectedIngredients.includes(ingredient.nombre);
            const card = document.createElement('div');
            card.className = `ingredient-card ${isSelected ? 'selected' : ''}`;
            card.setAttribute('data-name', ingredient.nombre);
            card.innerHTML = `
                <img src="${ingredient.imagen_url}" alt="${ingredient.nombre}">
                <span>${ingredient.nombre}</span>
            `;
            card.onclick = () => toggleSelect(card, ingredient.nombre);
            ingredientsGrid.appendChild(card);
        });
    }

    function toggleSelect(cardElement, nombre) {
        if (selectedIngredients.includes(nombre)) {
            selectedIngredients = selectedIngredients.filter(item => item !== nombre);
            cardElement.classList.remove('selected');
        } else {
            selectedIngredients.push(nombre);
            cardElement.classList.add('selected');
        }
    }

    function filtrar() {
        const texto = input.value.toLowerCase();
        const filtrados = dbIngredientes.filter(ing =>
            ing.nombre.toLowerCase().includes(texto)
        );
        renderIngredients(filtrados);
    }

    input.addEventListener('input', filtrar);
    renderIngredients(dbIngredientes);

    findRecipesBtn.addEventListener('click', async () => {
        if (selectedIngredients.length === 0) {
            alert("Selecciona al menos un ingrediente");
            return;
        }

        findRecipesBtn.innerText = "🍳 Generando receta...";
        findRecipesBtn.disabled = true;

        try {
            const receta = await obtenerRecetaIA(selectedIngredients);
        } catch (error) {
            console.error("Error:", error);
            alert(error.error.message);
        }
        findRecipesBtn.innerText = "🔍 Buscar Recetas con IA";
        findRecipesBtn.disabled = false;
    });
};