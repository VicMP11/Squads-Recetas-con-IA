import { GoogleGenAI } from "@google/genai";
import { GOOGLE_API_KEY } from "./secrets.js";

async function obtenerRecetaIA(ingredientesSeleccionados) {
    const prompt = `
        Actúa como un Chef profesional experto en cocina de aprovechamiento. 
        Basándote ÚNICAMENTE en esta lista de ingredientes: [${ingredientesSeleccionados.join(", ")}], 
        genera una receta creativa y deliciosa. Es OBLIGATORIO que respondas EXCLUSIVAMENTE con contenido HTML válido.  No incluyas introducciones, ni comentarios, ni bloques de código Markdown ni JSON.  
        La estructura del HTML debe ser exactamente esta:
    <div class="recipe-container">
        <div class="header">

            <h1 id="recipeTitle">Nombre creativo de la receta</h1>
            <div class="difficulty">DIFICULTAD: <span id="recipeDifficulty">Fácil, Media o Difícil</span></div>
        </div>

        <div class="section">
            <div class="ingredients-box" id="ingredientsList">
                <label class="item"><input type="checkbox">cantidad + nombre del ingrediente</label>
                <label class="item"><input type="checkbox">cantidad + nombre del ingrediente</label>
            </div>
        </div>

        <div class="section">
            <h2>Preparation</h2>
            <div class="steps" id="stepsContainer">
                <div class="step">
                    <div class="step-number">1</div>
                    <div>
                        <h3>Nombre corto del paso</h3>
                        <p>Explicación detallada de qué hacer</p>
                    </div>
                </div>
                <div class="step">
                    <div class="step-number">2</div>
                    <div>
                        <h3>Nombre corto del paso</h3>
                        <p>Explicación detallada de qué hacer</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
        Nota: Puedes añadir ingredientes básicos de despensa que no estén en la lista si son imprescindibles (sal, agua, aceite, pimienta).
    `;
    const ai = new GoogleGenAI({ apiKey: GOOGLE_API_KEY });

    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
    });

    console.log("Respuesta cruda:", response);
    const text = response.candidates[0].content.parts[0].text;

    document.getElementById("receta").innerHTML = text;
}
export { obtenerRecetaIA };

const accordionHeader = document.getElementById('accordionHeader');
const accordionContent = document.getElementById('accordionContent');
const arrowIcon = document.getElementById('arrowIcon');
accordionHeader.addEventListener('click', () => {
    toggleAccordion();
});
function toggleAccordion(forceOpen = null) {
    const isOpen = forceOpen !== null ? !forceOpen : accordionContent.classList.contains('open');
    
    if (!isOpen) {
        accordionContent.classList.add('open');
        arrowIcon.classList.add('rotated');
    } else {
        accordionContent.classList.remove('open');
        arrowIcon.classList.remove('rotated');
    }
}